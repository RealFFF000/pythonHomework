liczba = float(input("Podaj liczbe\n"))

if liczba > 0:
    print("no wieksza")
elif liczba < 0:
    print("no mniejsza")
else:
    print("no równa")