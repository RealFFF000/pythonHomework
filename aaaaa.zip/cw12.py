liczba = int(input("Podaj liczbę\n"))

liczba = liczba%2
if liczba == 0:
    print("liczba parzysta")
else:
    print("liczba nieparzysta")
