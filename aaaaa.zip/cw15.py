a = float(input("podaj liczbe a\n"))
b = float(input("podaj liczbe b\n"))
c = float(input("podaj liczbe c\n"))


print(a<b<c)