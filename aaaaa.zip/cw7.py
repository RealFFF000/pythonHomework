przy1 = float(input("Podaj długosc pierwszej przyprostokątnej: "))
przy2 = float(input("Podaj długosc drugiej przyprostokątnej: "))
print("długosc przeciwprostokątnej to", (przy1**2 + przy2**2)**0.5)