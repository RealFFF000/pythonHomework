a = float(input("podaj liczbe a\n"))

print("podana liczba zawiera się w przedziale od 5 do 15:", (a>=5 and a<=15))