kilometry = 12.25
mile = 7.38

mile_na_kilometry =  mile*1.61
kilometry_na_mile =  kilometry/1.61

print(mile, "mil to", round(mile_na_kilometry, 2), "km")
print(kilometry, "km to", round(kilometry_na_mile, 2), "mil")