print("Kurs","Programowania","w", sep="***", end="...")
print("Pythonie")