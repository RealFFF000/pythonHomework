liczba1 = input("podaj liczbe 1\n")
liczba2 = input("podaj liczbe 2\n")
liczba3 = input("podaj liczbe 3\n")

print(min([liczba1,liczba2,liczba3]))