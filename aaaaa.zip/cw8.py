x = float(input("Podaj wartosc x: "))
y = (1/(x+1/(x+1/(x+1/x))))
print(y)