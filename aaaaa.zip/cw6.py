x = float(input("Podaj wartosc x: "))
y = (3*x**3) - (2*x**2) + (3*x) - 1
print(y)