def far2celc(f):
    print((f - 32) * 5/9)

far2celc(float(input("temperatura w skali fahrenheita\n")))