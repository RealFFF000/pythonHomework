pomaranczowy_krol = 3
agnieszka = 5
adam = 6

print(pomaranczowy_krol, agnieszka, adam, sep=",")
pomaranczy_razem = pomaranczowy_krol + agnieszka + adam
print("calkowita liczba pomaranczy:", pomaranczy_razem)